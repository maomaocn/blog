-- MySQL dump 10.13  Distrib 5.7.23, for macos10.13 (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	5.7.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `desc` varchar(256) NOT NULL,
  `content` longtext NOT NULL,
  `published_date` date NOT NULL,
  `click_num` int(11) NOT NULL,
  `love_num` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article_user_id_b06c1b9c_fk_userprofile_id` (`user_id`),
  CONSTRAINT `article_user_id_b06c1b9c_fk_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'三步实现滚动条触动css动画效果','现在很多网站都有这种效果，我就整理了一下，分享出来。','现在很多网站都有这种效果，我就整理了一下，分享出来。利用滚动条来实现动画效果，ScrollReveal.js 用于创建和管理元素进入可视区域时的动画效果，帮助你的网站增加吸引力...','2019-11-03',5062,800,'images/t03.jpg',1),(2,'快乐的滋味','时光总是把身边的东西席卷而去，我也兢兢业业地当一个见证者，眼睁睁地看着那些东西离我而去，仿佛这一切都正常不过，彷佛心中明了默认这是岁月经过该有的姿态，现在才发现，不过只是我的情思还没有跟上我目睹现实的速度。情思总是会赶来，让我不断发出类似于今天的感慨，就在这热天夹杂在凉天的天气里，在雾气腾腾地过桥米线汤里。','天气很好，太阳很高，照得大地暖融融的，只给树下漏下几点清冷。但这好天气，来得让人有些猝不及防，让原本以为已经入秋的我，仍然根据几天前的天气穿着卫衣。这种天穿着卫衣，不免让人发热流汗。但这发热流汗的感觉，却让我再次感受到夏季的味道。\n\n明明天气温暖得出奇，我却突然有些伤感，只因这热不在连续几天热天的末尾，而是夹在许多凉天的中间。好似这热不能属于正常夏天的范围里，而是夏季在真正销匿之前的某种离别仪式，仿佛要来晒透最后一朵蔷薇，让他的颜色变成铁锈色，让他发出夏日里最后的气味，自身也便离去得无影无踪。\n\n这热，这衣袖间的汗，这有仪式感的离别，让我有关夏天与失去的所有回忆涌上心头。\n\n等待米线被端上桌的时候和晓暄说，早上去画室，给飞姐带了哈密瓜，拎着哈密瓜，我想到了芒果大叔。上个学期给飞姐带芒果的那一天，是芒果大叔在这个夏天出现的最后一天。当时芒果大叔说，小姑娘，你们买完这芒果，我这个夏天的最后一个芒果就卖完了，这个夏天就不再出来了。当时只是觉得芒果大叔说的这番话有些浪漫，夏天的最后一个芒果，竟是被我给买了。只是可惜，以后去画室再也不能吃到这么大这么甜的芒果了，况且，大叔还亲切和蔼呢。芒果大叔，应该是这个夏天第一个和我告别的人吧。\n\n菜还是没有上，讲完芒果大叔的我思绪繁杂。\n\n芒果大叔退隐江湖不久后，我听说中心食堂要装修了，我想着，装修就装修吧，装修不挺好的嘛。中心食堂停业前去买米粉，阿姨问我大几的，说她不记得了，我说大二的。阿姨又说，也不知道下个学期还能不能在这，可能都不能够了，那以后就再也见不着咯。傻站的我的确是傻站着，不明白阿姨说的这番话是什么意思，只是觉得她是不是听错了，我说我是大二的呀。就回了她说，阿姨，我大二，没有毕业呢，以后还来吃你家的米粉，还能见面的。阿姨正好给我递了粉，我也就走了。后来食堂装修了，我才又想起米粉阿姨对我说的话，才明白原来当时她因为不确定是否还能再见面而跟我告别啊，我这个傻娃子愣是什么都没听出来。托映雪当时一直安慰我的话，米粉阿姨会回来的。所幸她真的还在，还叫我帮她宣传了呢，所以大家快去吃中心食堂的米粉。\n\n米粉阿姨是还在，但是瓦罐汤大叔却不在了。刚开学的我完全没有意识到这个问题，因为也没进食堂几次。有一天中午，上课回来想去食堂买些吃的，脑子想着自己想吃什么，却没有什么想法，于是脑子又回到了上个学期的模式，当我对什么吃的都提不上想法的时候，我一般都会选择瓦罐汤，他简直就是我在纠结吃什么都没结果后的唯一选择。可是，瓦罐汤大叔好像不在了。天哪!瓦罐汤大叔居然不在了!知道事实的当天我还没有那么难过。但是，这凉天突然夹杂的热天，这夏天正式离别的感觉，却突然让我特别难过，瓦罐汤大叔也是在这个夏天离开了我的人，并且可能不会再见面了。\n\n上个学期，早上到食堂，不到十点，他的窗口常常没开业，窗口用着一张白色的布挂在那里，表明各式汤还在大瓦罐里熬熟中。即使开始开业了，也绝少有人像我一样大早上去喝汤，所以大叔常常偷懒，在窗口最里面玩着手机听着老式音乐。\n\n大叔叫李孟，我唯一一个知道名字的大叔。因为我常常要劳烦旁边窗口的人帮我叫一叫他帮我拿汤。那人往往把头一转，大喊声李孟。大叔便脚步轻快地跑出来询问我同学要什么。明明看起来还很年轻，大叔却给我一种很是安于生活的老成，白布围在腰间的角度，又让我觉得下一瞬他就要绘声绘色地给我来一个三国故事。后来去多了，与大叔虽然没表示相熟。但氛围总归不一样，毕竟我也是一个有段时间天天去喝他家汤的小姑娘。\n\n又是一天中午，和晓文一起去喝大叔家的汤。我在晓文前面，大叔把我的汤放在台上，我伸出手正欲抬起餐盘，跟晓文说我先去找位置了。大叔却一把摁住我的餐盘，我一愣抬头看着他。他却突然一笑对我说等等你朋友啊，她的马上就好咯。反应过来他说什么之后，我放开了餐盘，笑着答应着。原来大叔这么调皮啊。可是调皮的大叔和他好喝的汤却不在了。\n\n那他能去哪里啊。只咬着一根米线，燕林发出人生最真诚的疑问，眼泪都要从眶里出来了，仿佛瓦罐汤大叔不在大工食堂之后真的无处可去了一样。晓暄看着趴在桌子上的我，笑我一副悲天悯人的模样，很贴心的往我的碗里加了菜和鸡蛋，嘱咐着，来，别想了，吃菜，吃蛋，喝汤，快吃，别想了，你想了大叔也不会回来的。\n\n呜呜呜，居然这么想大叔和他的汤。\n\n这个夏天，除了已经告别已经离开、告别却没离开、没有告别却已经离开的人，还有一些人，他们未曾告别未曾离开却已经为我所失去。\n\n建管一楼女厕所的阿姨，虽然我们两人关系并不能称得上认识，但是不知为何我却仍执着于把她当作这个校园里我认识的大叔阿姨之一。\n\n我们没有过几次的交集，能数得上比较正式的也就一次。我光荣地把手机落在了洗手台，想想这交谈的缘由还真是很符合我的人设。才转身，阿姨就一把叫住了我。拾起手机的我表示完感谢之后正欲转身，但阿姨却给我讲了起来，东西可不能再忘带呀，上次也是有一个小姑娘把手机落这了，我也找不到她的人，只好拿去上交了，第二天还专门来谢谢我呢。\n\n我虽然微笑着在听，但是却有些苦恼，阿姨的年纪有些大了，我或许可以称她为阿婆，她的普通话，我听得不太懂，只听得了大概。问了我的家乡，我的年级。我知道她有个女儿，曾经在广西打过工，现在这几年倒是回来了。还有许多事，听得不大懂便也记得不太真切了。原先几次碰见她还认得我，后来时间一长，我也不在建管上课，即便碰见了她也没印象。\n\n再没有交谈，我只能从一楼厕所里窥探到她的生活状态，那个厕所，仿佛她的私人空间，总是被她打扫得干干净净的，厕所与墙的缝隙整整齐齐的摆放着被她叠好的纸箱，还有尼龙袋子装着的各种塑料瓶。洗手台旁边，拉过一根绳，时不时上边还会晾着几只袜子或是手套，每当这时，洗手台旁边总是飘着干净的肥皂味。挂着干净小袜子的厕所，想想都不会觉得糟糕。\n\n建管一楼厕所阿姨与建管一楼小卖店的阿姨熟识，她们年龄应该差不多，下课时，常常可以看到厕所阿姨坐在小卖店的门口，和小卖店阿姨聊天。\n\n小卖店阿姨，也不知我们何时习惯买东西偶尔攀谈几句的。我记得是她先开的口，她问我下午几节课，什么时候放假，我也不大记得当时放的是什么节假日了，只是我们渐渐攀谈起来。\n\n在那时我才知道，原来建管小卖店存在也不过也是几年时间。因为我一开学就在了，所以我不免以为她原本就一直在这的。小卖店的老板是阿姨的儿女，但是儿女工作太忙却没办法照看，于是这个重任就落在了他身上。那你平时会不会无聊呀?和她攀谈起来之后，我才考虑到这个问题。以前建管小卖店给我的感觉就是那里会一直坐着一个人，只要我买完东西给他看一下付款单就可以了。从未想过这个人整天坐在这地板都没有日光转移的店里，是否会无聊，怎样消磨时间。\n\n长时间未去建管，她自然也认不出我来，虽然没有攀谈，但是我终能从她偶在椅子上坐着偶倚靠着墙的动作，读懂了她的无聊与消磨时光。\n\n夏天过去了，不过告没告别，有些人也不在了。\n\n时光总是把身边的东西席卷而去，我也兢兢业业地当一个见证者，眼睁睁地看着那些东西离我而去，仿佛这一切都正常不过，彷佛心中明了默认这是岁月经过该有的姿态，现在才发现，不过只是我的情思还没有跟上我目睹现实的速度。情思总是会赶来，让我不断发出类似于今天的感慨，就在这热天夹杂在凉天的天气里，在雾气腾腾地过桥米线汤里。','2019-11-01',9012,5000,'images/t02.jpg',2),(3,'家家都有家长里短\n','身处闹市无人问，穷人和富人终于平等了。我所说的家长里短，是好朋友之间的谈天说地，说着说着自然就牵出了各自的家庭生活，既然说说无妨，听听也就无碍了，这也是朋友之间的交流，甭管男女，都别说自己清高，都别说自己脱俗，世界上哪有那么多正经事需要我们关注呢。','2019年10月29日。我以为家长里短都是老娘们儿挂在嘴上的谈资，我自己也是个娘们儿，自然也免不了家长里短的那一套，但是我绝不会东家长西家短，因为我不熟悉所在小区的任何一个人，就是住在同一层邻居，打个照面也仅限于点下头，更多的时候装作没看见。我特别适应这种状态，别管穷富，都身处闹市无人问，穷人和富人终于平等了。我所说的家长里短，是好朋友之间的谈天说地，说着说着自然就牵出了各自的家庭生活，既然说说无妨，听听也就无碍了，这也是朋友之间的交流，甭管男女，都别说自己清高，都别说自己脱俗，世界上哪有那么多正经事需要我们关注呢。\n\n我这刘同学总以为自己的身上流着贵族的血液，他很看不起同一所大院里一起长大的有些发小，觉得他们特颓废特无能特矫情特啃老，都这岁数了，很多人还没混出个人模狗样来。我说和他们比，你混的太好了。他还假装谦虚说自己不行，差远了。我也不知道他差在什么地方，要是觉得自己差，还有什么理由嘲讽别人呢?\n\n今天他与我聊天，一开口就非常气愤，我以为他又要对他的哪一位发小开骂了，没想到他一张嘴骂的竟然是他的哥哥姐姐。姐姐住着他父母留下的大房子，哥哥也想占，两人商量好把他踢出局外，平分房产。从那时起，哥哥姐姐与他8年没有来往。没想到后来事态发生了变化，姐姐想独占，哥哥到法院起诉，必须姐弟三人同时到场，哥哥才与他联系。最后法院宣判房产均分，每人三分之一的份额。打完官司，姐弟三人又形同陌路，谁也不理谁了，一晃，又过去了7、8年。\n\n最近有人给他带话，他的哥哥得了癌症，已经是晚期了。听到这个消息，他连眼皮都没抬一下，活该，他就应该是这个下场!夫人听说这个消息，不声不响去探望了大伯子，还给了5000块钱。我说还是你老婆通情达理，人都快不行了，你就别计较了。不是我计较，是他做的太绝了，对不起我，他掰着手指头给我历数了哥哥的三大可恨之处，当然全都与房子有关。我笑话他你看北京台的第三调解室多火呀，要不你也报名参加，凑凑热闹。','2019-11-01',6810,3000,'images/t01.jpg',1),(4,'第一次吃了“海底捞”\n','表妹说咱们出去吃饭，艳儿已经找好饭店了。我说就在家里吧，点外卖就行啊。三个人都反对，咱们多年没有相逢了，一定要请你好好吃一顿。我现在最不敢做的一件事就甩开腮帮子大吃大喝，我可是个糖尿病啊。表妹说偶尔吃一顿没啥大了不起，我也是糖尿病，我陪着你一起吃，甭管什么病，也不能把嘴扎起来，是吧?真是说到我心里去了，就像我有个同学的妈，她说的太好了，我才不管糖高糖低呢，哪怕明天要死了，我今天也要过嘴瘾。老太太都快活到90岁了，还结实着呢，她可是个多年的糖尿病患者啊。','2019年10月23日。正在微信上与好友聊得酣畅淋漓，突然被一打个电话打断了，一看来电显示，我的天，是我那当大官的表妹打来的，这可真是让我受宠若惊，不年不节的居然给我打来了电话，该不会出了什么事吧。好事抑或是坏事，应该是好事，如果是坏事不会给我打电话，瞒还瞒不住呢。电话接通后，表妹语气欢快，在家等着我们，再有10多分钟就到你家门口了。我一听慌得手忙脚乱，赶紧往脸上擦面霜，赶紧往腿上套罩裤，赶紧往身上穿外衣，赶紧换了一双鞋，等我刚一收拾停当，客人就到了门口。\n\n和表妹一起来的还有她的女儿艳儿和她的后老伴谷老师，这是我第一次见到他，古老师是他的官称，表妹直接叫他老古。进门后他们带来的东西摆了一地，表妹还说这次来的匆忙没带什么东西过来，还有点抱歉似的。我都糖尿病了，再给我带好吃的，我哪消受得了呀。\n\n表妹这次是到北京看病的，她的病和我一模一样，昨天已经到专科医院就诊过了，明天就要回去上班了。今天专程来看我，我们已经有好几年没见过面了，现在看见她自然感到分外亲切。还有谷老师与表妹站在一起十分般配，早就听说两人非常合得来，谷老师特别会照顾她，老来享福了，也真是不容易啊。\n\n表妹说咱们出去吃饭，艳儿已经找好饭店了。我说就在家里吧，点外卖就行啊。三个人都反对，咱们多年没有相逢了，一定要请你好好吃一顿。我现在最不敢做的一件事就甩开腮帮子大吃大喝，我可是个糖尿病啊。表妹说偶尔吃一顿没啥大了不起，我也是糖尿病，我陪着你一起吃，甭管什么病，也不能把嘴扎起来，是吧?真是说到我心里去了，就像我有个同学的妈，她说的太好了，我才不管糖高糖低呢，哪怕明天要死了，我今天也要过嘴瘾。老太太都快活到90岁了，还结实着呢，她可是个多年的糖尿病患者啊。\n\n外甥女脚下一踩油门，我们就到了她定好的吃饭的地界儿了，上到大厦的5层，她带我们进入了“海底捞”，早就听说过这家餐饮企业的名气了，可是从来也没光顾过。我很奇怪我那傻儿子怎么一次也不带我到这种有名的饭店来呢，指望着我自己到海底捞来打牙祭，那是我至死也办不到的事，不是我没钱，而是我穷命，再有钱也舍不得吃大餐呀。\n\n这海底捞最让我看好的就是我们一行四人每个人都可以有一个自己的涮汤锅底，还有随时更换的手巾板儿，服务生的服务更是没得说。在美好的就餐环境中，我们聊了一个痛快吃了一个肚歪，最后我都不知道吃了些什么，反正是捞起什么就往嘴里填什么，不过就是吃了一个名气，以后有人问我吃过海底捞吗，我的回答肯定是自豪的毋庸置疑。','2019-11-01',1226,121,'images/t03.jpg',3),(5,'微怒','何必为怒','<p>开了外挂的人生</p>','2019-11-01',4,0,'images/t03.jpg',5),(6,'来世','人有没有来世','<p>溪水潺潺，清风潇潇，每一天都是如此平凡，生命本没有什么不同，每一朵花，每一片树叶，长得相似，实则各不相同。</p>\r\n\r\n<p>夏日总是燥热的，在这个偏僻的小山村，住着几百庄稼人，还有这排列整齐却显破旧的房屋。纵使夏日骄阳，汗流浃背，人们也不舍得休息。只有在一处房屋前，有几人在焦急的等待，里面还时不时的传出几声妇人的痛苦的呻吟声。没过多久，里面传来了婴儿的啼哭，所有人都松了一口气。就在所有人都认为一切已经皆大欢喜，准备办一场酒宴的时候，一阵骚乱传来，里面的孕妇血崩死了。有人在这个世上出生，就有人死亡，或许他的命运就是从此刻开始改变的。</p>\r\n\r\n<p>时间如流水般，静静地流淌，转瞬之间，已是十五年后，当初的婴孩也步入了少年时期，这个年纪，本该是肆意张扬，潇洒快活的时候，而少年却无法像同龄人一般肆意玩闹，他每天都很忙很累。不是像别人一样被敦促学习，对于他来说，学不学习都不重要了，因为将这高中读完，他就只能缀学回家，帮父母料理农活。实际上，从很久之前，他就开始下地干活了，每天除了学习之外，其余的时间都是在田野里度过的。</p>\r\n\r\n<p>他母亲走后的前几年，他的父亲对他还算不错，可是他的父亲毕竟还年轻，不可能一直一个人，到了第五年的时候，她终于被领进了家里。在这个贫穷而落后的地方，人们为了挣一口饱饭费尽了心力，对于那些与自己非亲非故的人，往往都是事不关己高高挂起，即使路上遇到一个快饿死的人，也不会因为可怜他而施舍他一粒米，最多不过是等他死了，挖个坑给他埋了，免得暴尸荒野。所以，对于一个陌生女人生下的孩子，还是现任丈夫的前妻孩子，怎会有所怜爱。在她刚来的时候，还不敢太过明目张胆的做什么，毕竟是他唯一的儿子，未来还得靠他养老送终。可是，在她来到这里的第三年后，庄稼收成越来越不好，<a href=\"https://www.duanwenxue.com/jingdian/shenghuo/\">生活</a>越来越困难，于是她的丈夫最终决定进城打工。他走的那一天，轻抚着她微微隆起的腹部，说：&ldquo;别太辛苦了，好好把孩子生下来，我很快就回来。&rdquo;</p>\r\n\r\n<p>就是从那一天开始，他开始了无休止的忙碌，每天都有干不完的活，还要去照顾这个未出世的弟弟或妹妹。可是即便如此，也未能博得这个继母的好感，他每天都要干许多的活，但是回到家里，她却只给他一点点吃的，晚上，他常常被饿醒。有一次，他实在饿极了，去厨房找吃的，被她发现了，直接一巴掌扇了过去，看着她眼中的厌恶，那一刻，他清醒了。</p>\r\n\r\n<p>好不容易到了过年的时候，他的父亲也回来了，他也能够闲下来休息一下了。大年三十的那一天晚上，一家人坐在餐桌上，上面摆满了鸡鸭鱼肉，这是他一年中吃过的最好、最饱的一次，也是最<a href=\"https://www.duanwenxue.com/diary/xingfu/\">幸福</a>的&middot;一次，如果没有最后那一句话。</p>\r\n\r\n<p>吃完饭后，他在厨房洗碗，他和她一起在卧房内谈话，他抚着她的肚子说道：&ldquo;就快了，这一定是个男孩。我想过了，等明年他初中一读完，就让他和我一起进城打工，多赚些钱，等我们的孩子到了上学的年纪后，就将他送到城里读书，以后也能出人头地。&rdquo;虽然他们说话的声音不大，但他还是听到了，那一刹那，他好像在被人丢到冰冷的河水里浸泡过一样，浑身都是冷的，连心都失去了温度。</p>\r\n\r\n<p>他觉得好无助，难道自己就活该受这样的苦吗?像个奴隶一般卑微而又渺小的活着，没有母亲的爱，现在连仅存的一点父爱也没了。这个喜庆的日子，本该合家团圆，可他感觉自己像是多余的，自己好像再也不属于这个家。他独自一人出了门，想要离开这里，可是却无处可去，他对外面的世界一无所知。他曾经听他的一个同学说过，城里有高高的楼房，还有许多的小汽车，以及各种各样的吃的玩的，他也曾向往过，以为只要自己好好学习，就可以去外面看看，可是现在，这些好像都不重要了。他就着么漫无目的的走着，有走到了这一条湍急的河流旁，天气很冷，而他身上只有一件薄薄的有些宽大的棉衣，冷风拂过，也不觉得有多冷。望着眼前的这条河流，河水很宽很深也很冷，但无论天气有多么冷，它也不会结冰，就这么一直流动着，冲刷着一切。</p>\r\n\r\n<p>或许一切该结束了，没有希望的人生要来干嘛，他想着，再往前走一步，就一步&hellip;&hellip;</p>\r\n\r\n<p>又是一个阳光明媚的日子，依旧是那处熟悉的茅屋，以及妇人痛苦的哀嚎声，随后是一阵欢乐的笑声，一切都很和谐安好。对了，还有那个新砌的土堆，安安静静的立在那儿，除了上面刚冒出的一点绿意，再也没有别的了。</p>\r\n\r\n<p>一个生命，一个故事，匆匆来，又匆匆走，始终是一无所有，只留下无可奈何。</p>','2019-11-01',10,0,'images/p05.jpg',5);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_tags`
--

DROP TABLE IF EXISTS `article_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `article_tags_article_id_tag_id_9ea24d7b_uniq` (`article_id`,`tag_id`),
  KEY `article_tags_tag_id_55b93824_fk_tag_id` (`tag_id`),
  CONSTRAINT `article_tags_article_id_ebbe35ec_fk_article_id` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  CONSTRAINT `article_tags_tag_id_55b93824_fk_tag_id` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_tags`
--

LOCK TABLES `article_tags` WRITE;
/*!40000 ALTER TABLE `article_tags` DISABLE KEYS */;
INSERT INTO `article_tags` VALUES (1,1,1),(2,2,2),(3,3,1),(4,3,2),(5,5,3),(6,6,4);
/*!40000 ALTER TABLE `article_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add 用户表',6,'add_userprofile'),(22,'Can change 用户表',6,'change_userprofile'),(23,'Can delete 用户表',6,'delete_userprofile'),(24,'Can view 用户表',6,'view_userprofile'),(25,'Can add 文章表',7,'add_article'),(26,'Can change 文章表',7,'change_article'),(27,'Can delete 文章表',7,'delete_article'),(28,'Can view 文章表',7,'view_article'),(29,'Can add 标签表',8,'add_tag'),(30,'Can change 标签表',8,'change_tag'),(31,'Can delete 标签表',8,'delete_tag'),(32,'Can view 标签表',8,'view_tag'),(33,'Can add 评论表',9,'add_comment'),(34,'Can change 评论表',9,'change_comment'),(35,'Can delete 评论表',9,'delete_comment'),(36,'Can view 评论表',9,'view_comment'),(37,'Can add 留言表',10,'add_message'),(38,'Can change 留言表',10,'change_message'),(39,'Can delete 留言表',10,'delete_message'),(40,'Can view 留言表',10,'view_message'),(41,'Can add Bookmark',11,'add_bookmark'),(42,'Can change Bookmark',11,'change_bookmark'),(43,'Can delete Bookmark',11,'delete_bookmark'),(44,'Can view Bookmark',11,'view_bookmark'),(45,'Can add User Setting',12,'add_usersettings'),(46,'Can change User Setting',12,'change_usersettings'),(47,'Can delete User Setting',12,'delete_usersettings'),(48,'Can view User Setting',12,'view_usersettings'),(49,'Can add User Widget',13,'add_userwidget'),(50,'Can change User Widget',13,'change_userwidget'),(51,'Can delete User Widget',13,'delete_userwidget'),(52,'Can view User Widget',13,'view_userwidget'),(53,'Can add log entry',14,'add_log'),(54,'Can change log entry',14,'change_log'),(55,'Can delete log entry',14,'delete_log'),(56,'Can view log entry',14,'view_log'),(57,'Can add captcha store',15,'add_captchastore'),(58,'Can change captcha store',15,'change_captchastore'),(59,'Can delete captcha store',15,'delete_captchastore'),(60,'Can view captcha store',15,'view_captchastore');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `captcha_captchastore`
--

DROP TABLE IF EXISTS `captcha_captchastore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_captchastore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `challenge` varchar(32) NOT NULL,
  `response` varchar(32) NOT NULL,
  `hashkey` varchar(40) NOT NULL,
  `expiration` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hashkey` (`hashkey`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captcha_captchastore`
--

LOCK TABLES `captcha_captchastore` WRITE;
/*!40000 ALTER TABLE `captcha_captchastore` DISABLE KEYS */;
INSERT INTO `captcha_captchastore` VALUES (1,'YQZB','yqzb','b4c79d72c84e9528ecffe4ad2abf6d9d096cd69a','2019-10-30 20:39:19.716434'),(2,'LNNG','lnng','18341d2e5180a5188c7b0474a53d773298833a95','2019-10-30 20:42:08.711785'),(3,'XKIE','xkie','784cf5295dc3cb23d004f4f258717f954d1c7d38','2019-10-30 20:42:12.420131'),(4,'ACEO','aceo','a44a159d9a657e1595ecced911a7740bbea2827d','2019-10-30 20:44:40.285063'),(5,'IZQN','izqn','2a9ef60c1966b68b1fb9331cd6a9193630459cdc','2019-10-30 20:46:18.187423'),(6,'YPDH','ypdh','a76f1c497a6e146c0f73d4c74bd3c6a215d7f4be','2019-10-30 20:48:18.735318'),(7,'JHFG','jhfg','315b38bf938bba7edf755100492aa3e81a5ff699','2019-10-30 20:48:51.988643'),(8,'VNWW','vnww','8f23f90f16327d2b322398dc77c941765079cd44','2019-10-30 20:48:52.499840'),(9,'GABV','gabv','47e0df51ec63f1f00270fb30cab38ba44d166801','2019-10-30 20:48:52.769357'),(10,'UOKO','uoko','afadf6c6aa4222a73a51e0fbb6d9a802b00d4a53','2019-10-30 20:48:52.949899'),(11,'VYVP','vyvp','b63b27674f061ec3725a998857162c57983b078d','2019-10-30 20:48:53.149608'),(12,'TIQR','tiqr','3bf2208e54112322af2acf81d655e635066abf31','2019-10-30 20:48:53.335832'),(13,'GNLL','gnll','0cbd02d7471f93c83db4184a312cccc156ceafad','2019-10-30 20:48:53.512244'),(14,'DHJS','dhjs','ac122fb084be320bfb6567481f69bf0a91bcdbbb','2019-10-30 20:48:53.671819'),(15,'IUGM','iugm','00de02a1488c49cac8226208bd8f16b5479eed46','2019-10-30 20:48:53.864645'),(16,'VHYI','vhyi','f503e1c348ddee3fda3518b79e38b2f5fa30408e','2019-10-30 20:48:54.047570'),(17,'MCJN','mcjn','091634bf80aaf2ca0bb44c01a8b936a51f00c5bd','2019-10-30 20:48:54.421319'),(18,'YVWV','yvwv','5658de7e1bab6048c70a054fa70d28a8273b6bd2','2019-10-30 20:48:54.607749'),(19,'ZUZV','zuzv','6bd8475b4ab1e5c28720d32106ebefea0b261a04','2019-10-30 20:48:54.847747'),(20,'UONJ','uonj','2a8ee190e8fb83fe3b2f79d6a73530ba89233ef2','2019-10-30 20:48:55.039632'),(21,'GRYV','gryv','ea167c09e305ce4c4e0bf341b93caf8151279285','2019-10-30 20:48:55.231591'),(22,'SNPZ','snpz','3419f6171777e745f54f0ed70a186ddb19fd37da','2019-10-30 20:48:55.486829'),(23,'YIAS','yias','0b57c61d94e18d2ce81d5986301c85928cdc554b','2019-10-30 20:48:56.430364'),(24,'NEGI','negi','9ee37b47dacd7846a2c187e34498ad24c242013c','2019-10-30 20:48:57.109602'),(25,'PZKR','pzkr','852ca2f5b9677e7bb5f5701fd6583b5b84e60a7d','2019-10-30 20:48:57.653317'),(26,'EFQO','efqo','b874cb3054e5294d268f667e43a675d1f0f911a2','2019-10-30 20:48:58.550205'),(27,'ADUZ','aduz','2e7d3e7a2c4c3fb032718b43fd9ec182cb3bd051','2019-10-30 20:48:59.261288'),(28,'NFEB','nfeb','5e9b79043413f8be6a65e7ea13686dc11197089b','2019-10-30 20:49:00.117737'),(29,'LMHG','lmhg','2e3e86ba23a2415a5d2feafc011e5e206cc9dd4e','2019-10-30 20:49:00.630677'),(30,'HMQS','hmqs','386d8810861a6c8ba632f0c991accdc422feb154','2019-10-30 20:49:01.094007'),(31,'YDIF','ydif','1a71070518635f9983886d1909c55c2a9eaac85a','2019-10-30 20:49:01.444955'),(32,'IHRD','ihrd','ff803f8d1896f773b75292599ccf4e3cbd0703d2','2019-10-30 20:49:01.725785'),(33,'CWYN','cwyn','58b24ef937798f21a95e1ec564c974d501f7c4d4','2019-10-30 20:49:02.021072'),(34,'WSIM','wsim','e13a790b64ef9563f9b9b695b2ddbc3f216b4e71','2019-10-30 20:49:02.774000'),(35,'NBCK','nbck','545f40262a4766907bb4d327eaa896de3ad58608','2019-10-30 20:49:03.501532'),(36,'CJWV','cjwv','90f1c60f684d3be1991cab68fa24f7ee9892c8dc','2019-10-30 20:49:04.420830'),(37,'QWCS','qwcs','1c2424be80929f88d9f8c835fe11e5f741a79c91','2019-10-30 20:49:05.973705'),(38,'RTOZ','rtoz','db80fd31b07175f082314a6efd365aa8edbba608','2019-10-30 20:49:08.631338'),(39,'CTFE','ctfe','619e2ef49bb795dbf05144cc4d72ae1a28ec1dc5','2019-10-30 20:51:16.985272'),(40,'VDKU','vdku','c60104e21f827c7d1cc7a819aea575a1e1c07901','2019-10-30 20:52:17.918798'),(41,'CIFO','cifo','1783aaf518143d22cf3570042425be45d2ba3b64','2019-10-30 21:00:26.567254'),(42,'ZJZJ','zjzj','ce85c78ea23210e52f5aae3731fb3dce604da338','2019-10-30 21:00:37.215482'),(43,'DACG','dacg','b47f2e79c008f6a08f5c6a83416c78b5d10c8962','2019-10-30 21:00:39.429702'),(44,'OZYF','ozyf','3129e8598c95aeae2d14fca5c0e1edec1aa64451','2019-10-31 09:19:50.667936'),(45,'AFHJ','afhj','d554595449c9afbd0ea854f119bc82a42719b47c','2019-10-31 09:19:59.070178'),(46,'EBSY','ebsy','c76e535b6ddfa25a7e4c07bb17ecb8a3426c36d5','2019-10-31 09:20:00.127559'),(47,'YTBX','ytbx','e5b78f71057dbe2328aabdabbd6ccf01d996ecc3','2019-10-31 09:20:04.524339'),(48,'JYXJ','jyxj','16e99c7aa23892b11aec2c244473d78aa375c095','2019-10-31 09:20:05.307302'),(49,'RZVO','rzvo','70365a8081ba4ee6b9b1246ffb555afe78aa24bb','2019-10-31 09:20:06.139224'),(50,'LVGN','lvgn','225899de8db3f9de6984bf00cea848ff02812637','2019-10-31 09:21:17.707394'),(51,'VWHQ','vwhq','4023d36fdea466a2e5f984795b922b03a61e3460','2019-10-31 09:22:42.220078'),(52,'FNJB','fnjb','b0796b822daf11deb765e858f428d8e581f9aac7','2019-10-31 09:22:42.872694'),(53,'SKSK','sksk','87569c666cdd6d259098af3629278e215f5e8b3c','2019-10-31 09:22:43.368260'),(54,'CVJP','cvjp','c271c71421adcb7328f0eb1e76d318e8c2b5e1ec','2019-10-31 09:22:43.848636'),(55,'HEVE','heve','1361a7b09481d5584e735204d04c855055126bd8','2019-10-31 09:22:45.101392'),(56,'MAZL','mazl','514a9214f032854b5ada15c8c44cd1a545e5d228','2019-10-31 09:22:45.591620'),(57,'NABL','nabl','2a30433268d92903e17cba2736b19e98238e7a3d','2019-10-31 09:22:45.920470'),(58,'YPOW','ypow','67dd6a500a62e6efc7096494bb65c34f4b0f04da','2019-10-31 09:22:46.127382'),(59,'NLQB','nlqb','9aec9447080bbf2f6f66914d7d419b600f0e89ba','2019-10-31 09:22:46.350238'),(60,'PIOR','pior','0565ae0d5c6193a2d5608cb1fbce15ce784731bb','2019-10-31 09:22:46.581543'),(61,'DIID','diid','751caead99c914140f23daa0c579cd8bcc6c1adc','2019-10-31 09:22:46.767015'),(62,'AJDO','ajdo','a8d88031ea6a6546f2e8a972df1f2e5addd28be4','2019-10-31 09:22:46.974598'),(63,'JJHP','jjhp','03d68506c0af6bf78dd6fa22162f5d6463746c5d','2019-10-31 09:22:47.158660'),(64,'GGDX','ggdx','3b96f2e0cc553ce4fc9f80a60e5f434580735c88','2019-10-31 09:22:47.350651'),(65,'KNEV','knev','cff0e99beca121e089e8c6ae9acf9c4e44cbdb21','2019-10-31 09:22:47.510485'),(66,'IEUS','ieus','f644667eb8d49d2755226b22de12e3a8273c4011','2019-10-31 09:22:47.688001'),(67,'JSUG','jsug','336b1cfe24163fc17cfcd1fe04fcd1706654ab01','2019-10-31 09:22:47.862650'),(68,'KWSF','kwsf','c49625361f6cce3687289063800fb8b5ed8c1bfc','2019-10-31 09:22:48.038363'),(69,'ZUCL','zucl','35b86faae0019bd93848a8fca9419ce79e8305af','2019-10-31 10:05:31.197638'),(70,'FOHJ','fohj','832278d219d85525eb348daf578ef08015722e1a','2019-10-31 10:05:42.874778'),(71,'LKBH','lkbh','355348ccfadebaf044bff1196d0f2e52387666dc','2019-10-31 10:05:43.826057'),(72,'VFUF','vfuf','659a153f373cac456c23b10af50dded0443cfc3f','2019-10-31 10:06:57.846664'),(73,'IQLW','iqlw','aa0b6f11627149ccf5db590a6eca31f6b765d5d9','2019-10-31 10:07:00.034427'),(74,'APOV','apov','dccd5712fe3abdb6bb553f5615085fe83b327c30','2019-10-31 10:07:01.439696'),(75,'NMRM','nmrm','826dda801bf72be94692a0a9b8d55a46324a26ec','2019-10-31 10:19:51.563610'),(76,'PVBS','pvbs','35ddfa2d1d2f32d6d58516eff815ac2ef20c282c','2019-10-31 10:40:38.777648'),(77,'QCHQ','qchq','464a31f0f438de806b2a6c0a6a4fc581d1a691ae','2019-10-31 10:44:24.195925'),(78,'UOWJ','uowj','fdd5318114b6a4590d2feb2d929db8294368ba2b','2019-10-31 10:44:40.858217'),(79,'WDSS','wdss','e5a69ec4a4ac2833701a911ced8780150e96c98a','2019-10-31 10:44:43.110185'),(80,'TIFZ','tifz','4d5c66397e1c8c5e96e73b9a7aeb0b7b02231fc0','2019-10-31 11:02:11.199277'),(81,'SXKB','sxkb','2f765c670629258edbb188a50a4192bc5db29ae6','2019-10-31 11:02:49.599807'),(82,'WYMF','wymf','95d5d414ccfada30065ff74cebe1d21821fcd080','2019-10-31 11:03:56.106243'),(83,'JVIH','jvih','25c29681627829e0461d2db1377d343b4f768dd2','2019-10-31 11:12:54.052247'),(84,'NUGC','nugc','ce49efe33cca9a3f7718abe75ed1539d8aa36967','2019-10-31 11:12:59.225650'),(85,'UCZX','uczx','6ee38ff0608fd62a2f8e1ad3304788b6aed1e472','2019-10-31 11:19:46.911181');
/*!40000 ALTER TABLE `captcha_captchastore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `date` datetime(6) NOT NULL,
  `article_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_article_id_1de4311c_fk_article_id` (`article_id`),
  CONSTRAINT `comment_article_id_1de4311c_fk_article_id` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'猜猜我是谁','不知道说些什么','2019-10-31 08:10:15.143000',1),(2,'www','前排','2019-10-31 18:00:07.890782',1);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_userprofile_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(7,'article','article'),(9,'article','comment'),(10,'article','message'),(8,'article','tag'),(3,'auth','group'),(2,'auth','permission'),(15,'captcha','captchastore'),(4,'contenttypes','contenttype'),(5,'sessions','session'),(6,'user','userprofile'),(11,'xadmin','bookmark'),(14,'xadmin','log'),(12,'xadmin','usersettings'),(13,'xadmin','userwidget');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-10-30 09:32:45.568529'),(2,'contenttypes','0002_remove_content_type_name','2019-10-30 09:32:45.604419'),(3,'auth','0001_initial','2019-10-30 09:32:45.645041'),(4,'auth','0002_alter_permission_name_max_length','2019-10-30 09:32:45.723147'),(5,'auth','0003_alter_user_email_max_length','2019-10-30 09:32:45.730341'),(6,'auth','0004_alter_user_username_opts','2019-10-30 09:32:45.739797'),(7,'auth','0005_alter_user_last_login_null','2019-10-30 09:32:45.748357'),(8,'auth','0006_require_contenttypes_0002','2019-10-30 09:32:45.750725'),(9,'auth','0007_alter_validators_add_error_messages','2019-10-30 09:32:45.757293'),(10,'auth','0008_alter_user_username_max_length','2019-10-30 09:32:45.766196'),(11,'auth','0009_alter_user_last_name_max_length','2019-10-30 09:32:45.772541'),(12,'user','0001_initial','2019-10-30 09:32:45.809128'),(13,'admin','0001_initial','2019-10-30 09:32:45.868159'),(14,'admin','0002_logentry_remove_auto_add','2019-10-30 09:32:45.906689'),(15,'admin','0003_logentry_add_action_flag_choices','2019-10-30 09:32:45.922033'),(16,'article','0001_initial','2019-10-30 09:32:45.996608'),(17,'article','0002_auto_20190509_1803','2019-10-30 09:32:46.110521'),(18,'article','0003_auto_20190510_0954','2019-10-30 09:32:46.133336'),(19,'article','0004_auto_20190510_1109','2019-10-30 09:32:46.146448'),(20,'article','0005_comment','2019-10-30 09:32:46.166700'),(21,'article','0006_message','2019-10-30 09:32:46.187799'),(22,'article','0007_message_icon','2019-10-30 09:32:46.209032'),(23,'auth','0010_alter_group_name_max_length','2019-10-30 09:32:46.228747'),(24,'auth','0011_update_proxy_permissions','2019-10-30 09:32:46.243926'),(25,'sessions','0001_initial','2019-10-30 09:32:46.259597'),(26,'user','0002_auto_20190508_0927','2019-10-30 09:32:46.272743'),(27,'user','0003_userprofile_yunicon','2019-10-30 09:32:46.295465'),(28,'user','0004_remove_userprofile_icon','2019-10-30 09:32:46.317309'),(29,'xadmin','0001_initial','2019-10-30 09:32:46.393794'),(30,'xadmin','0002_log','2019-10-30 09:32:46.457132'),(31,'xadmin','0003_auto_20160715_0100','2019-10-30 09:32:46.504262'),(32,'user','0002_userprofile_icon','2019-10-30 17:01:26.684228'),(33,'captcha','0001_initial','2019-10-30 20:34:08.144971'),(34,'article','0002_auto_20191031_1709','2019-10-31 17:09:25.297562'),(35,'article','0003_auto_20191101_0935','2019-11-01 09:35:39.391801');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('od7moc06i2qj0cgw71tn24bvpx4qoqm7','YTQwZDA3NGJmYWM5ZjY1MGRhZTYzYWZlM2FlNTk2YTJiYzA3NDc3Nzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyNmNjZjNmYWUwODJhNTFjMzE5ODBkZjc4YmIwMTUxMmI0YjkzZGM2In0=','2019-11-13 14:14:43.672103');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(50) NOT NULL,
  `content` longtext NOT NULL,
  `date` datetime(6) NOT NULL,
  `icon` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,'羊肉','huhauhuahuaaa','2019-10-31 17:57:44.868513','/static/images/tx2.jpg');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
INSERT INTO `tag` VALUES (1,'test1'),(2,'茶余饭后小点心，我的最爱'),(3,'时光'),(4,'冲动的惩罚'),(5,'历史轨迹'),(6,'爱转角'),(7,'玫瑰情'),(8,'爱的心痛'),(9,'折翅天使');
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile`
--

DROP TABLE IF EXISTS `userprofile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `icon` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile`
--

LOCK TABLES `userprofile` WRITE;
/*!40000 ALTER TABLE `userprofile` DISABLE KEYS */;
INSERT INTO `userprofile` VALUES (1,'pbkdf2_sha256$150000$VNNs5JPa8msa$2OzkKAOCCE39mrs0m9Faa8zIlgyx1V0NsKsTlgcDPyk=','2019-10-31 09:11:39.398908',0,'zhangsan','','','student11@163.com',0,1,'2019-10-30 14:12:24.779393','18914668363','media/mine.png'),(2,'pbkdf2_sha256$150000$qtUDKx9wpa1Z$Qfgj8TosHrDPMtW7bbjuIZs6lhTADUA1cMdtNIi08uQ=',NULL,0,'wangwu','','','9090@qq.com',0,1,'2019-10-30 17:39:16.338086','18814668389','media/mine.png'),(3,'pbkdf2_sha256$150000$Iz2jfIvPFV7Z$5zd4d4L7PwyAj/RzATUeXmYImYCnjMCru1okrb5sDZk=',NULL,0,'RMB','','','RMB@163.com',0,1,'2019-10-30 17:45:15.821840','18814668300','media/mine.png'),(4,'pbkdf2_sha256$150000$KrzS4Scdn2uk$wktE+4nJFEcOFSG0uR+6VBndHppnwelGAeIdmk/XQJQ=',NULL,0,'uiui','','','uiui@163.com',0,1,'2019-10-30 18:01:06.830865','18814664363','media/mine.png'),(5,'pbkdf2_sha256$150000$4NktOVx0d7Gq$xG9XYjyCHgDSgxdq8I75G2JsKNObdFHdDpmn0LA2Prs=','2019-10-31 15:45:56.886792',1,'alex1','','','872992572@qq.com',1,1,'2019-10-30 20:54:11.991427','18814668363','media/2019/10/31/girl_4lk2X6Z.jpg'),(6,'pbkdf2_sha256$150000$Jf5GnB7tI4PU$0tv+tftXcSWiDgkn0NUfdncj/vK8X6+aWpyuCQga9yU=',NULL,0,'aaa','','','872992272@qq.com',0,1,'2019-10-31 09:01:35.122844','18814648363','media/mine.png');
/*!40000 ALTER TABLE `userprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile_groups`
--

DROP TABLE IF EXISTS `userprofile_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userprofile_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userprofile_groups_userprofile_id_group_id_850640d8_uniq` (`userprofile_id`,`group_id`),
  KEY `userprofile_groups_group_id_e25cf300_fk_auth_group_id` (`group_id`),
  CONSTRAINT `userprofile_groups_group_id_e25cf300_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `userprofile_groups_userprofile_id_ffc3c019_fk_userprofile_id` FOREIGN KEY (`userprofile_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile_groups`
--

LOCK TABLES `userprofile_groups` WRITE;
/*!40000 ALTER TABLE `userprofile_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userprofile_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile_user_permissions`
--

DROP TABLE IF EXISTS `userprofile_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userprofile_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userprofile_user_permiss_userprofile_id_permissio_b528d16d_uniq` (`userprofile_id`,`permission_id`),
  KEY `userprofile_user_per_permission_id_7fd54787_fk_auth_perm` (`permission_id`),
  CONSTRAINT `userprofile_user_per_permission_id_7fd54787_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `userprofile_user_per_userprofile_id_50a5dd7d_fk_userprofi` FOREIGN KEY (`userprofile_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile_user_permissions`
--

LOCK TABLES `userprofile_user_permissions` WRITE;
/*!40000 ALTER TABLE `userprofile_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userprofile_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xadmin_bookmark`
--

DROP TABLE IF EXISTS `xadmin_bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xadmin_bookmark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `url_name` varchar(64) NOT NULL,
  `query` varchar(1000) NOT NULL,
  `is_share` tinyint(1) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `xadmin_bookmark_content_type_id_60941679_fk_django_co` (`content_type_id`),
  KEY `xadmin_bookmark_user_id_42d307fc_fk_userprofile_id` (`user_id`),
  CONSTRAINT `xadmin_bookmark_content_type_id_60941679_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `xadmin_bookmark_user_id_42d307fc_fk_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xadmin_bookmark`
--

LOCK TABLES `xadmin_bookmark` WRITE;
/*!40000 ALTER TABLE `xadmin_bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `xadmin_bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xadmin_log`
--

DROP TABLE IF EXISTS `xadmin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xadmin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `ip_addr` char(39) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` varchar(32) NOT NULL,
  `message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `xadmin_log_content_type_id_2a6cb852_fk_django_content_type_id` (`content_type_id`),
  KEY `xadmin_log_user_id_bb16a176_fk_userprofile_id` (`user_id`),
  CONSTRAINT `xadmin_log_content_type_id_2a6cb852_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `xadmin_log_user_id_bb16a176_fk_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xadmin_log`
--

LOCK TABLES `xadmin_log` WRITE;
/*!40000 ALTER TABLE `xadmin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `xadmin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xadmin_usersettings`
--

DROP TABLE IF EXISTS `xadmin_usersettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xadmin_usersettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(256) NOT NULL,
  `value` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `xadmin_usersettings_user_id_edeabe4a_fk_userprofile_id` (`user_id`),
  CONSTRAINT `xadmin_usersettings_user_id_edeabe4a_fk_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xadmin_usersettings`
--

LOCK TABLES `xadmin_usersettings` WRITE;
/*!40000 ALTER TABLE `xadmin_usersettings` DISABLE KEYS */;
INSERT INTO `xadmin_usersettings` VALUES (1,'dashboard:home:pos','',5);
/*!40000 ALTER TABLE `xadmin_usersettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xadmin_userwidget`
--

DROP TABLE IF EXISTS `xadmin_userwidget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xadmin_userwidget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` varchar(256) NOT NULL,
  `widget_type` varchar(50) NOT NULL,
  `value` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `xadmin_userwidget_user_id_c159233a_fk_userprofile_id` (`user_id`),
  CONSTRAINT `xadmin_userwidget_user_id_c159233a_fk_userprofile_id` FOREIGN KEY (`user_id`) REFERENCES `userprofile` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xadmin_userwidget`
--

LOCK TABLES `xadmin_userwidget` WRITE;
/*!40000 ALTER TABLE `xadmin_userwidget` DISABLE KEYS */;
/*!40000 ALTER TABLE `xadmin_userwidget` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-05  9:50:45
