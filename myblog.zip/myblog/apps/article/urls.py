from django.conf.urls.static import static
from django.contrib.auth.decorators import login_required
from django.urls import path

from myblog import settings
from article.views import *
app_name='article'


urlpatterns = [
    path('detail', article_detail, name='detail'),#文章详情页
    path('show', article_show, name='article_show'),#学无止境
    path('write', write_article, name='write'),#写博客
    path('comment', article_comment, name='comment'),#评论
    path('message', blog_message, name='message')#留言
]
