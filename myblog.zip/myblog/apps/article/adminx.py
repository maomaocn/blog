import xadmin
from article.models import Article, Tag, Comment


class ArticleXadmin(object):
    list_display=['title','click_num','love_num']


class TagXadmin(object):
    list_display=['id','name']



xadmin.site.register(Article,ArticleXadmin)
xadmin.site.register(Tag,TagXadmin)


class CommentXadmin(object):
    list_display = ['nickname', 'content', 'date', 'article']

xadmin.site.register(Comment,CommentXadmin)
# xadmin.site.register(Tag,TagXadmin)