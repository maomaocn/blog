import re

from captcha.models import CaptchaStore
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password
from django.db.models import Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect

# Create your views here.
from django.urls import reverse
from django.views import View

from user.forms import RegisterForm, LoginForm, CaptchaTestForm
from user.models import UserProfile
from utils import send_email

def index(request):
    if request.method=='GET':
        return HttpResponse('ok')
class User_Index(View):
    def get(self,request):
        return render(request, 'index.html')

#注册
class User_Register(View):
    def get(self,request):
        return render(request,'user/register.html')
    def post(self,request):
        rform=RegisterForm(request.POST)# 使用form获取数据
        if rform.is_valid():
            username=rform.cleaned_data.get('username')
            email=rform.cleaned_data.get('email')
            password=rform.cleaned_data.get('password')
            mobile=rform.cleaned_data.get('mobile')
            if not UserProfile.objects.filter(Q(username=username) | Q(mobile=mobile)).exists():
                # 注册到数据库中
                password = make_password(password)  # 密码加密
                user = UserProfile.objects.create(username=username, password=password, email=email, mobile=mobile)
                if user:
                    return redirect(reverse("user:blog_login"))
            else:
                return render(request, 'user/register.html', context={'msg': '用户名或者手机号码已经存在！'})
        error = rform.errors
        l = re.findall('[\u4E00-\u9FA50-9]+', str(error))
        print(l,'l')
        return render(request, 'user/register.html', context={'msg': '注册失败，重新填写！'})
#登录
class User_Login(View):
    def get(self,request):
        return render(request,'user/login.html')
    def post(self,request):
        rform=LoginForm(request.POST)# 使用form获取数据
        if rform.is_valid():
            username=rform.cleaned_data.get('username')
            password=rform.cleaned_data.get('password')
            user=authenticate(username=username,password=password)
            if user:
                login(request,user)
                return redirect(reverse("user:blog_index"))
            else:
                return render(request, 'user/login.html', context={'msg': '用户名或者手机号码不存在'})
        # print(rform.errors)
        error=rform.errors
        l=re.findall('[\u4E00-\u9FA50-9]+',str(error))
        return render(request, 'user/login.html', context={'msg':l[0]})

# 用户注销
class User_Logout(View):
    def get(self,request):
        print(request.user)
        logout(request)
        return redirect(reverse('user:blog_index'))

# 忘记密码
class ForgetPassword(View):
    def get(self,request):
        form = CaptchaTestForm()
        return render(request, 'user/forget_pwd.html', context={'form': form})

    def post(self, request):
        # 获取提交的邮箱，发送邮件，通过发送的邮箱链接设置新的密码
        email = request.POST.get('email')
        form = CaptchaTestForm()
        # 给此邮箱地址发送邮件
        try:
            result = send_email(email, request)
        except Exception as e:

            return render(request, 'user/forget_pwd.html', context={'form':form,'msg':'请检查您的邮箱是否正确'})
        if result:
            # return HttpResponse("邮件发送成功！赶快去邮箱更改密码！<a href='/'>返回首页>>> </a>")
            return redirect(reverse('user:blog_index'))
        return render(request, 'user/forget_pwd.html', context={'form':form})

# 定义一个路由验证验证码
def valide_code(request):
    if request.is_ajax():
        key = request.GET.get('key')
        code = request.GET.get('code')
        captche = CaptchaStore.objects.filter(hashkey=key).first()
        print(key,code,captche,sep='\n')
        if captche.response == code.lower():#字符转小写
            # 正确
            data = {'status': 1}
        else:
            # 错误的
            data = {'status': 0}
        return JsonResponse(data)



# 更新密码
class Update_PWD(View):
    def get(self,request):
        c = request.GET.get('c')
        return render(request, 'user/update_pwd.html', context={'c': c})

    def post(self, request):
        code = request.POST.get('code')
        uid = request.session.get(code)
        try:
            user = UserProfile.objects.get(pk=uid)
        except Exception as e :
            return render(request, 'user/login.html', context={'msg': '更新失败！'})
        # 获取密码
        pwd = request.POST.get('password')
        repwd = request.POST.get('repassword')
        if pwd == repwd and user:
            pwd = make_password(pwd)
            user.password = pwd
            user.save()
            return render(request, 'user/login.html', context={'msg': '用户密码更新成功！'})
        else:
            return render(request, 'user/update_pwd.html', context={'msg': '更新失败！'})


# 用户的个人中心  login(request,user)   user--->继承自abstractuser

class User_Center(View):
    def get(self,request):
        user = request.user
        # icon = user.icon
        # print(icon)
        return render(request, 'user/center.html', context={'user': user})
    def post(self, request):
        user = request.user
        username = request.POST.get('username')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        icon = request.FILES.get('icon')
        # print(type(icon))
        # print(icon.name)
        # print(icon.read())
        # 更新用户
        user.username = username
        user.email = email
        user.mobile = mobile
        user.icon = icon  # ImageField(upload_to='')
        user.save()
        return render(request, 'user/center.html', context={'user': user})


# 用户的个人中心  login(request,user)   user--->继承自abstractuser
# @login_required
# def user_center(request):
#     user = request.user
#     if request.method == 'GET':
#
#         return render(request, 'user/center.html', context={'user': user})
#     else:
#         username = request.POST.get('username')
#         email = request.POST.get('email')
#         mobile = request.POST.get('mobile')
#         icon = request.FILES.get('icon')
#         # print(type(icon))
#         # print(icon.name)
#         # print(icon.read())
#         # 更新用户
#         user.username = username
#         user.email = email
#         user.mobile = mobile
#         user.icon = icon  # ImageField(upload_to='')
#         user.save()
#
#         return render(request, 'user/center.html', context={'user': user})