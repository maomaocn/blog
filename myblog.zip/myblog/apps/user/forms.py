import re
from captcha.fields import CaptchaField
from django.contrib.auth.hashers import make_password, check_password
from django.core.exceptions import ValidationError
from django.forms import ModelForm, Form, EmailField
from django import forms

from user.models import UserProfile


class RegisterForm(ModelForm):
    class Meta:
        model=UserProfile
        fields=['username','email','mobile','password']

    def clean_username(self):
        username=self.cleaned_data.get('username')
        result = re.match(r'[a-zA-Z]\w{2,}', username)
        if not result:
            raise ValidationError('用户名必须字母开头')
        return username

class LoginForm(Form):
    username = forms.CharField(max_length=50, min_length=0,label='用户名')
    password = forms.CharField(required=True, error_messages={'required': '必须填写密码'}, label='密码',
                               widget=forms.widgets.PasswordInput)
    # class Meta:
    #     model=UserProfile
    #     fields=['username','password']

    def clean_username(self):
        username=self.cleaned_data.get('username')
        if not UserProfile.objects.filter(username=username).exists():
            raise ValidationError('用户名不存在')
        return username
    def clean_password(self):
        password=self.cleaned_data.get('password')
        username=self.clean_username()
        password2 = UserProfile.objects.filter(username=username).first().password
        flag=check_password(password,password2)
        if not flag:
            raise ValidationError('密码错误')
        return password



# 验证码captcha的Form
class CaptchaTestForm(forms.Form):
    email = EmailField(required=True, error_messages={'required': '必须填写邮箱'},label='邮箱')
    captcha = CaptchaField()