from user.models import UserProfile
import xadmin

xadmin.sites.register(UserProfile)