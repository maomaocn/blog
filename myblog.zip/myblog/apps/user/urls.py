from django.conf.urls.static import static
from django.contrib.auth.decorators import login_required
from django.urls import path

from myblog import settings
from user import views
app_name='user'
urlpatterns = [
    path('index/', views.User_Index.as_view(),name='blog_index'),#首页
    path('register/', views.User_Register.as_view(),name='blog_register'),#注册
    path('login/', views.User_Login.as_view(),name='blog_login'),#登录
    path('logout/', views.User_Logout.as_view(),name='blog_logout'),#注销
    path('forget_pwd', views.ForgetPassword.as_view(), name='blog_forget_pwd'),#忘记密码
    path('valide_code', views.valide_code, name='blog_valide_code'),
    # path('center', views.user_center, name='blog_user_center'),
    path('update_pwd', views.Update_PWD.as_view(), name='blog_update_pwd'),  # 更新密码
    path('center', login_required(views.User_Center.as_view()), name='blog_user_center'),  # 更新密码


]

# + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)