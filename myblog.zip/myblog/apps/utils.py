# 发送邮件
import uuid

from django.core.mail import send_mail

from myblog.settings import EMAIL_HOST_USER
from user.models import UserProfile


def send_email(email, request):
    subject = '个人博客找回密码'
    user = UserProfile.objects.filter(email=email).first()
    ran_code = uuid.uuid4()
    print(ran_code,'ran_code')
    print(type(ran_code))
    ran_code = str(ran_code)
    print(type(ran_code))
    ran_code = ran_code.replace('-', '')
    request.session[ran_code] = user.id
    message = '''
     可爱的用户:
            <br>
            您好！此链接用户找回密码，请点击链接: <a href='http://127.0.0.1:8000/update_pwd?c=%s'>更新密码</a>，
            <br>
            如果链接不能点击，请复制：<br>
            http://127.0.0.1:8000/update_pwd?c=%s

           个人博客团队
    ''' % (ran_code, ran_code)
    # 发送邮件send_mail
    result = send_mail(subject, "", EMAIL_HOST_USER, [email, ], html_message=message)
    return result